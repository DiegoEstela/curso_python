from setuptools import setup

setup(
    name="mi_primer_paquete",
    version='1.0',
    author="Diego Estela",
    description='Estamos creando el primer paquete distribuido',
    author_email="die.estela@gmail.com",
    packages=['packages']
)
